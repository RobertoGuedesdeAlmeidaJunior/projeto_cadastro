from django.contrib import admin
from .models import AgendaModel

# Registro do modelo AgendaModel
admin.site.register(AgendaModel)